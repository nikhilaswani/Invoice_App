function Footer() {
  return (
    <div
      style={{
        height: 60,
        backgroundColor: "lightgrey",
        color: "black",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        fontWeight: "bold",
      }}
    >
      Footer
    </div>
  );
}

export default Footer;
